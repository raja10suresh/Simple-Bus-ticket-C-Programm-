#include<iostream>
#include<string>
using namespace std;

int main()
{
  int x,y;
  cout<<"Route : ";
  cin>>x;
  cout<<"Enter the stage : ";
  cin>>y;
  if(x==1)
  {
    cout<<"Route UP to DOWN. \n";
    switch (y)
    {
      case 1:
      cout<<"Lalgudi To Cathram Bus Terminals.\n";
      cout<<"Rs 18.00";
      break;
      case 2:
      cout<<"Mandhurai To Cathram Bus Terminals.\n";
      cout<<"Rs 15.00";
      break;
      case 3:
      cout<<"Kela Valadi To Cathram Bus Terminals.\n";
      cout<<"Rs 12.00";
      break;
      case 4:
      cout<<"Mela Valadi To Cathram Bus Terminals.\n";
      cout<<"Rs 12.00";
      break;
      case 5:
      cout<<"ThalaKudi To Cathram Bus Terminals.\n";
      cout<<"Rs 10.00";
      break;
      case 6:
      cout<<"No.1 TollGate to Cathram Bus Terminals.\n";
      cout<<"Rs 10.00";
      break;
      case 7:
      cout<<"TV Kovil To Cathram Bus Terminals.\n";
      cout<<"Rs 8.00";
      break;
      case 8:
      cout<<"Mamblasalai To Cathram Bus Terminals.\n";
      cout<<"Rs 5.00";
      break;
    }
  }
  else if(x==2)
  {
    cout<<"Reute DOWN to UP. \n";
    switch (y)
    {
      case 1:
      cout<<"Cathram Bus Terminals To Mamblasalai.\n";
      cout<<"Rs 5.00";
      break;
      case 2:
      cout<<"Cathram Bus Terminals To TV Kovil.\n";
      cout<<"Rs 8.00";
      break;
      case 3:
      cout<<"Cathram Bus ThalaKudi To No.1 TollGate.\n";
      cout<<"Rs 10.00";
      break;
      case 4:
      cout<<"Cathram Bus Terminals To ThalaKudi.\n";
      cout<<"Rs 10.00";
      break;
      case 5:
      cout<<"Cathram Bus Terminals To MelaValadi.\n";
      cout<<"Rs 12.00";
      break;
      case 6:
      cout<<"Cathram Bus Terminals To KelaValadi.\n";
      cout<<"Rs 12.00";
      break;
      case 7:
      cout<<"Cathram Bus Terminals To Mandhrai.\n";
      cout<<"Rs 15.00";
      break;
      case 8:
      cout<<"Cathram Bus Terminals To Lalgudi.\n";
      cout<<"Rs 18.00";
      break;
    }
  }
}